	<!-- Sidenav -->
		<div id="mySidenav" class="sidenav">
		  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
			<a href="index.html">Home</a>
			<a class="dropdown-btn">About
			 <i class="fa fa-caret-down"></i>
		 	</a>
			 <div class="dropdown-container">
				 <a href="our_company.php">Our Company</a>
				 <a href="about_reba.php">About Reba</a>
				 <a href="FAQ.php">FAQ</a>
				 <a href="gallery.php">Gallery</a>
			  </div>
		  <a href="services_and_rates.php">Services & Rates</a>
		  <a href="contact.php">Contact</a>
		</div>

		<a onclick="openNav()" class="icon menuBtn alt fa-bars"></a>